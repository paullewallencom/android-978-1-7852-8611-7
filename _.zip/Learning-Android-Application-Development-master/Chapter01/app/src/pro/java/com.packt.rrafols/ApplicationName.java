package com.packt.rrafols;

public class ApplicationName {
    public static final String APPLICATION_FLAVOR = "pro";
}
