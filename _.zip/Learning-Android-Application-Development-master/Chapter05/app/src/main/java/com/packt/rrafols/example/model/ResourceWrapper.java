package com.packt.rrafols.example.model;


public class ResourceWrapper {
    private Resource resource;

    public Resource getResource() {
        return resource;
    }
    public void setResource(Resource resource) {
        this.resource = resource;
    }
}






