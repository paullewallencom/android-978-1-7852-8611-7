package com.packt.rrafols.example.model;

public class Model {
    public List list;

    public List getList() {
        return list;
    }
    public void setList(List list) {
        this.list = list;
    }
}




