package com.packt.rrafols.example.model;

public class Resource {
    private String classname;
    private Fields fields;

    public String getClassname() {
        return classname;
    }
    public void setClassname(String classname) {
        this.classname = classname;
    }
    public Fields getFields() {
        return fields;
    }
    public void setFields(Fields fields) {
        this.fields = fields;
    }
}





